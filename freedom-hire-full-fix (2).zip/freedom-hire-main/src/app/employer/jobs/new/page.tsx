"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

type Company = { id: string; name: string | null; verification_status: string | null };

const EMPLOYMENT_TYPES = [
 { value: "full-time", label: "Полная занятость" },
 { value: "part-time", label: "Частичная занятость" },
 { value: "contract", label: "Контракт/проект" },
 { value: "internship", label: "Стажировка" },
];

const FORMATS = [
 { value: "office", label: "Офис" },
 { value: "remote", label: "Удалёнка" },
 { value: "hybrid", label: "Гибрид" },
];

const EXPERIENCE_LEVELS = [
 { value: "no_experience", label: "Без опыта" },
 { value: "junior", label: "До 1 года опыта" },
 { value: "middle", label: "1–3 года опыта" },
 { value: "senior", label: "3–5 лет опыта" },
 { value: "lead", label: "5+ лет опыта" },
];

const EDUCATION_LEVELS = [
 { value: "", label: "Не важно" },
 { value: "school", label: "Среднее" },
 { value: "college", label: "Среднее специальное" },
 { value: "bachelor", label: "Бакалавр" },
 { value: "master", label: "Магистр" },
 { value: "phd", label: "PhD / Доктор наук" },
];

function fmt(value: string) {
 const d = value.replace(/\D/g, "");
 if (!d) return "";
 return d.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}
function parse(value: string) {
 const d = value.replace(/\D/g, "");
 return d ? Number(d) : null;
}

export default function NewJobPage() {
 const router = useRouter();
 const supabase = useMemo(() => createClient(), []);

 const [loading, setLoading] = useState(true);
 const [saving, setSaving] = useState(false);
 const [msg, setMsg] = useState<string | null>(null);
 const [companies, setCompanies] = useState<Company[]>([]);
 const [companyId, setCompanyId] = useState("");

 const [title, setTitle] = useState("");
 const [description, setDescription] = useState("");
 const [requirements, setRequirements] = useState("");
 const [benefits, setBenefits] = useState("");
 const [city, setCity] = useState("");
 const [format, setFormat] = useState("office");
 const [employmentType, setEmploymentType] = useState("full-time");
 const [experience, setExperience] = useState("middle");
 const [salaryFromText, setSalaryFromText] = useState("");
 const [salaryToText, setSalaryToText] = useState("");
 const [salaryNegotiable, setSalaryNegotiable] = useState(false);
 const [tagsText, setTagsText] = useState("");
 const [isActive, setIsActive] = useState(true);
 const [responsibilities, setResponsibilities] = useState("");
 const [educationLevel, setEducationLevel] = useState("");
 const [companyOffers, setCompanyOffers] = useState("");

 const salaryFrom = useMemo(() => parse(salaryFromText), [salaryFromText]);
 const salaryTo = useMemo(() => parse(salaryToText), [salaryToText]);

 useEffect(() => {
 (async () => {
 const { data: userData } = await supabase.auth.getUser();
 if (!userData.user) { router.replace("/auth"); return; }

 const { data: comps, error } = await supabase
 .from("companies")
 .select("id,name,verification_status")
 .eq("owner_id", userData.user.id)
 .order("created_at", { ascending: false });

 if (error) { setMsg(error.message); setLoading(false); return; }

 const list = (comps ?? []) as Company[];
 setCompanies(list);
 // Используем только верифицированные компании
 const verified = list.filter(c => c.verification_status === 'verified' || c.verification_status === 'approved');
 if (verified[0]) setCompanyId(verified[0].id);
 if (!list.length) setMsg("Сначала создайте компанию.");
 setLoading(false);
 })();
 }, [router, supabase]);

 async function onCreate() {
 setMsg(null);
 if (!title.trim()) { setMsg("Введите название вакансии."); return; }
 if (!companyId) { setMsg("Выберите компанию."); return; }
 if (!description.trim()) { setMsg("Введите описание вакансии."); return; }
 if (!city.trim()) { setMsg("Введите город."); return; }
 if (!salaryNegotiable && salaryFrom && salaryTo && salaryFrom > salaryTo) {
 setMsg("Зарплата 'от' не может быть больше 'до'."); return;
 }

 setSaving(true);

 const tags = tagsText
 .split(",")
 .map((t) => t.trim())
 .filter(Boolean);

 const { error } = await supabase.from("jobs").insert({
 company_id: companyId,
 title: title.trim(),
 description: description.trim(),
 requirements: requirements.trim() || null,
 city: city.trim(),
 work_format: format,
 employment_type: employmentType,
 experience_level: experience,
 salary_from: salaryNegotiable ? null : salaryFrom,
 salary_to: salaryNegotiable ? null : salaryTo,
 salary_negotiable: salaryNegotiable,
 tags: tags.length ? tags : null,
 is_active: isActive,
 responsibilities: responsibilities.trim() || null,
 education_level: educationLevel || null,
 benefits: [
 benefits.trim(),
 companyOffers.trim() ? `Что предлагает компания:\n${companyOffers.trim()}` : ""
 ].filter(Boolean).join("\n\n") || null,
 });

 setSaving(false);
 if (error) { setMsg(error.message); return; }
 router.replace("/employer/jobs");
 }

 if (loading) {
 return (
 <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 rounded-full border-2 animate-spin"
            style={{ borderColor: "rgba(196,173,255,0.2)", borderTopColor: "var(--lavender)" }} />
          <div className="text-sm font-body" style={{ color: "rgba(255,255,255,0.3)" }}>Загрузка...</div>
        </div>
      </div>
 );
 }

 const inputCls = "w-full rounded-2xl bg-black/20 border border-white/10 px-4 py-3 outline-none focus:border-violet-500/50 transition";
 const labelCls = "text-xs text-white/60 block mb-2";

 // Проверяем есть ли верифицированная компания
 const verifiedCompany = companies.find(c => c.verification_status === 'verified' || c.verification_status === 'approved');
 const pendingCompany = companies.find(c => c.verification_status === 'pending');
 const rejectedCompany = companies.find(c => c.verification_status === 'rejected');

 // Если нет верифицированной компании — показываем сообщение
 if (!verifiedCompany) {
   return (
     <div className="min-h-screen text-white p-6" style={{ background: "var(--ink)" }}>
       <div className="max-w-2xl mx-auto mt-20">
         <div className="rounded-3xl border p-8 text-center"
           style={{ 
             background: pendingCompany ? "rgba(251,191,36,0.05)" : rejectedCompany ? "rgba(239,68,68,0.05)" : "rgba(255,255,255,0.03)",
             borderColor: pendingCompany ? "rgba(251,191,36,0.2)" : rejectedCompany ? "rgba(239,68,68,0.2)" : "rgba(255,255,255,0.1)"
           }}>
           
           <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4"
             style={{ 
               background: pendingCompany ? "rgba(251,191,36,0.15)" : rejectedCompany ? "rgba(239,68,68,0.15)" : "rgba(92,46,204,0.15)",
             }}>
             <span className="text-3xl">
               {pendingCompany ? "⏳" : rejectedCompany ? "❌" : "🏢"}
             </span>
           </div>

           {pendingCompany ? (
             <>
               <h2 className="text-xl font-semibold mb-2" style={{ color: "#fbbf24" }}>
                 Компания на проверке
               </h2>
               <p className="text-white/60 mb-4">
                 Ваша компания <strong>"{pendingCompany.name}"</strong> находится на модерации. 
                 Обычно проверка занимает до 24 часов.
               </p>
               <p className="text-white/40 text-sm">
                 После верификации вы сможете публиковать вакансии.
               </p>
             </>
           ) : rejectedCompany ? (
             <>
               <h2 className="text-xl font-semibold mb-2" style={{ color: "#f87171" }}>
                 Компания отклонена
               </h2>
               <p className="text-white/60 mb-4">
                 К сожалению, компания <strong>"{rejectedCompany.name}"</strong> не прошла проверку.
               </p>
               <p className="text-white/40 text-sm mb-4">
                 Свяжитесь с поддержкой для уточнения причин.
               </p>
             </>
           ) : (
             <>
               <h2 className="text-xl font-semibold mb-2">
                 Создайте компанию
               </h2>
               <p className="text-white/60 mb-4">
                 Для публикации вакансий необходимо сначала зарегистрировать компанию.
               </p>
             </>
           )}

           <button 
             onClick={() => router.push("/employer")}
             className="btn-primary rounded-xl px-6 py-2.5 font-semibold text-white mt-2">
             ← Вернуться в кабинет
           </button>
         </div>
       </div>
     </div>
   );
 }

 return (
 <div className="min-h-screen  text-white p-6" style={{ background: "var(--ink)" }}>
 <div className="max-w-4xl mx-auto">

 <div className="flex items-center justify-between gap-3 mb-6">
 <div>
 <h1 className="text-2xl font-semibold">Новая вакансия</h1>
 <p className="text-white/50 text-sm mt-1">Заполните все обязательные поля</p>
 </div>
 <div className="flex gap-2">
 <button onClick={() => router.push("/employer/jobs")}
 className="rounded-2xl bg-white/10 border border-white/10 px-5 py-2 hover:bg-white/15 transition">
 Отмена
 </button>
 <button onClick={onCreate} disabled={saving || !companyId}
 className="rounded-2xl btn-primary px-5 py-2 font-semibold  transition disabled:opacity-50">
 {saving ? "Сохраняю..." : "Опубликовать"}
 </button>
 </div>
 </div>

 {msg && (
 <div className="mb-4 rounded-2xl bg-red-500/10 border border-red-500/20 px-4 py-3 text-sm text-red-300">
 {msg}
 </div>
 )}

 <div className="space-y-4">

 {/* Основное */}
 <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
 <h2 className="text-sm font-semibold text-white/70 mb-4">Основная информация</h2>
 <div className="space-y-4">

 <div>
 <label className={labelCls}>Название вакансии *</label>
 <input value={title} onChange={(e) => setTitle(e.target.value)}
 placeholder="Например: Frontend разработчик" className={inputCls} />
 </div>

 <div>
 <label className={labelCls}>Компания *</label>
 <select value={companyId} onChange={(e) => setCompanyId(e.target.value)} className={inputCls}>
 {companies.map((c) => (
 <option key={c.id} value={c.id}>{c.name || c.id}</option>
 ))}
 </select>
 {!companies.length && (
 <button onClick={() => router.push("/onboarding/employer")}
 className="mt-2 text-sm text-violet-400 hover:underline">
 + Создать компанию
 </button>
 )}
 </div>

 <div>
 <label className={labelCls}>Описание вакансии *</label>
 <textarea value={description} onChange={(e) => setDescription(e.target.value)}
 placeholder="Чем предстоит заниматься, о команде и проекте..."
 rows={5} className={inputCls} />
 </div>

 <div>
 <label className={labelCls}>Требования к кандидату</label>
 <textarea value={requirements} onChange={(e) => setRequirements(e.target.value)}
 placeholder="Опыт, навыки, образование..."
 rows={4} className={inputCls} />
 </div>

 <div>
 <label className={labelCls}>Условия и бенефиты</label>
 <textarea value={benefits} onChange={(e) => setBenefits(e.target.value)}
 placeholder="Зарплата, ДМС, обучение, офис..."
 rows={3} className={inputCls} />
 </div>

 <div>
 <label className={labelCls}>Обязанности (каждая с новой строки)</label>
 <textarea value={responsibilities} onChange={(e) => setResponsibilities(e.target.value)}
 placeholder={"— Разработка новых функций\n— Code review\n— Участие в планировании"}
 rows={4} className={inputCls} />
 </div>

 <div>
 <label className={labelCls}>Что предлагает компания</label>
 <textarea value={companyOffers} onChange={(e) => setCompanyOffers(e.target.value)}
 placeholder={"— Конкурентная зарплата\n— Гибкий график\n— ДМС для сотрудника и семьи"}
 rows={4} className={inputCls} />
 </div>
 </div>
 </div>

 {/* Детали */}
 <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
 <h2 className="text-sm font-semibold text-white/70 mb-4">Детали работы</h2>
 <div className="grid md:grid-cols-2 gap-4">

 <div>
 <label className={labelCls}>Город *</label>
 <input value={city} onChange={(e) => setCity(e.target.value)}
 placeholder="Ташкент" className={inputCls} />
 </div>

 <div>
 <label className={labelCls}>Формат работы</label>
 <select value={format} onChange={(e) => setFormat(e.target.value)} className={inputCls}>
 {FORMATS.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
 </select>
 </div>

 <div>
 <label className={labelCls}>Тип занятости</label>
 <select value={employmentType} onChange={(e) => setEmploymentType(e.target.value)} className={inputCls}>
 {EMPLOYMENT_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
 </select>
 </div>

 <div>
 <label className={labelCls}>Опыт работы</label>
 <select value={experience} onChange={(e) => setExperience(e.target.value)} className={inputCls}>
 {EXPERIENCE_LEVELS.map((l) => <option key={l.value} value={l.value}>{l.label}</option>)}
 </select>
 </div>

 <div>
 <label className={labelCls}>Уровень образования</label>
 <select value={educationLevel} onChange={(e) => setEducationLevel(e.target.value)} className={inputCls}>
 {EDUCATION_LEVELS.map((l) => <option key={l.value} value={l.value}>{l.label}</option>)}
 </select>
 </div>
 </div>
 </div>

 {/* Зарплата */}
 <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
 <h2 className="text-sm font-semibold text-white/70 mb-4">Зарплата</h2>
 <label className="flex items-center gap-2 cursor-pointer mb-4">
 <input type="checkbox" checked={salaryNegotiable}
 onChange={(e) => setSalaryNegotiable(e.target.checked)} className="rounded" />
 <span className="text-sm text-white/70">По договорённости</span>
 </label>
 {!salaryNegotiable && (
 <div className="grid md:grid-cols-2 gap-4">
 <div>
 <label className={labelCls}>От (сум)</label>
 <input inputMode="numeric" value={salaryFromText}
 onChange={(e) => setSalaryFromText(fmt(e.target.value))}
 placeholder="3 000 000" className={inputCls} />
 </div>
 <div>
 <label className={labelCls}>До (сум)</label>
 <input inputMode="numeric" value={salaryToText}
 onChange={(e) => setSalaryToText(fmt(e.target.value))}
 placeholder="5 000 000" className={inputCls} />
 </div>
 </div>
 )}
 </div>

 {/* Теги и публикация */}
 <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
 <h2 className="text-sm font-semibold text-white/70 mb-4">Навыки и публикация</h2>
 <div className="space-y-4">
 <div>
 <label className={labelCls}>Теги/навыки (через запятую)</label>
 <input value={tagsText} onChange={(e) => setTagsText(e.target.value)}
 placeholder="React, TypeScript, Node.js" className={inputCls} />
 {tagsText && (
 <div className="mt-2 flex flex-wrap gap-2">
 {tagsText.split(",").map((t) => t.trim()).filter(Boolean).map((tag) => (
 <span key={tag} className="text-xs px-2 py-1 rounded-full bg-violet-600/20 text-violet-300 border border-violet-500/20">
 {tag}
 </span>
 ))}
 </div>
 )}
 </div>
 <label className="flex items-center gap-3 cursor-pointer">
 <div onClick={() => setIsActive((v) => !v)}
 className={`relative w-11 h-6 rounded-full transition-colors ${isActive ? "bg-violet-600" : "bg-white/20"}`}>
 <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${isActive ? "translate-x-5" : "translate-x-0.5"}`} />
 </div>
 <span className="text-sm text-white/70">
 {isActive ? "Опубликовать сразу" : "Сохранить как черновик"}
 </span>
 </label>
 </div>
 </div>

 </div>

 <div className="mt-6 flex justify-end gap-3">
 <button onClick={() => router.push("/employer/jobs")}
 className="rounded-2xl bg-white/10 border border-white/10 px-6 py-3 hover:bg-white/15 transition">
 Отмена
 </button>
 <button onClick={onCreate} disabled={saving || !companyId}
 className="rounded-2xl btn-primary px-6 py-3 font-semibold  transition disabled:opacity-50">
 {saving ? "Сохраняю..." : "Опубликовать вакансию"}
 </button>
 </div>
 </div>
 </div>
 );
}